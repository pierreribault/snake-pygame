# Snake Game

### Setup

Setup for Mac

```bash
  brew install sdl2 sdl2_image sdl2_mixer sdl2_ttf pkg-config
  python3 -m pip install pygame==2.0.0
```

Setup for Mac M1

```bash
  brew install sdl2 sdl2_image sdl2_mixer sdl2_ttf pkg-config
  python3 -m pip install pygame==2.0.0.dev6 --no-cache-dir

```
